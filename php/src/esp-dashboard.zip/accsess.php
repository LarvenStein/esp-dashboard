<?php
function getAdminUser() {
    return 'Admin';
}

function getAdminPassword() {
    return 'changeme';
}

function getUserPassword() {
    return '1234';
}